<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "chatbot_db", 3307);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from form
$reply = $_POST['reply'];
$reply_to_id = $_POST['reply_to_id'];

// Insert reply as 'Bot' (admin reply)
$stmt = $conn->prepare("INSERT INTO messages (sender, message, timestamp) VALUES (?, ?, NOW())");
$sender = "Bot";
$stmt->bind_param("ss", $sender, $reply);
$stmt->execute();
$stmt->close();

$conn->close();

// Redirect back to admin dashboard
header("Location: admin_dashboard.php");
exit();
?>
